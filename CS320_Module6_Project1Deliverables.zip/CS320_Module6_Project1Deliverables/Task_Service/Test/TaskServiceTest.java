import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
/*Task Service test cases include:
*Add task
*update test
* Duplicate test, check for doubles
* Delete Task test*/

class TaskServiceTest {
    //Add Task test
    @Test
    void addTaskTest(){
        TaskService service = new TaskService();
        Task task = new Task(
                "1234567890",
                "Task 1",
                "Gather requirements");


        assertTrue(service.addTask(task));
    }

    //Duplicate Task test
    @Test
    void taskDuplicateTest(){
        TaskService service = new TaskService();

        //Task 1
        Task task1 = new Task(
                "1234567890",
                "Task 1",
                "Gather requirements");

        //The Duplicate^^^
        Task task2 = new Task(
                "1234567890",
                "Task 2",
                "System design");

        service.addTask(task1);
        assertThrows (IllegalArgumentException.class,() -> {
            service.addTask(task2);
        });
    }

    // Update task name test
    @Test
    void taskUpdateTest() {
        TaskService service = new TaskService();

        Task task = new Task(
                "1234567890",
                "Task 1",
                "Gather requirements");

        service.addTask(task);

        assertTrue(service.updateTaskName(
                "1234567890",
                "Updated Task"));

        assertEquals("Updated Task", task.getTaskName());
    }

    //Update Task Description test
    @Test
    void taskDescriptionUpdateTest() {
        TaskService service = new TaskService();

        Task task = new Task(
                "1234567890",
                "Task 1",
                "Gather requirements");

        service.addTask(task);

        assertTrue(service.updateTaskDescription(
                "1234567890",
                "System design"));

        assertEquals("System design", task.getTaskDescription());
    }

    //Delete Task test
    @Test
    void deleteTaskTest(){
        TaskService service = new TaskService();
        Task task = new Task(
                "1234567890",
                "Task 1",
                "Gather requirements");
        service.addTask(task);

        assertTrue(service.deleteTask("1234567890"));
    }
}