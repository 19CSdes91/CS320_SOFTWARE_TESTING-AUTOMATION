import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
/*Test cases for Task include:
* Happy path, testing valid task creation
* Null test, is it empty
* Length test, is it too long
* */
class TaskTest {

//"Happy path"Test
    @Test

   void testTaskCreation() {

        Task task = new Task(
                "1234567890",
                "Task 1",
                "Gather requirements");

        assertEquals("1234567890",task.getTaskId());
        assertEquals("Task 1",task.getTaskName());
        assertEquals("Gather requirements",task.getTaskDescription());
    }

    //Task ID NULL test
    @Test

    void testTaskIdNull() {

        assertThrows(IllegalArgumentException.class,() ->{
            new Task(
                    null,
                    "Task 1",
                    "Gather requirements");
        });
    }

    //Task name NULL test
    @Test

    void testTaskNameNull() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Task(
                    "1234567890",
                   null,
                    "Gather requirements");
        });
    }

    //Task Description NULL test
    @Test
    void testTaskDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "1234567890",
                    "Task 1",
                    null);
        });
    }

    //Task ID Character TOO LONG length test
    @Test

    void testTaskIdLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Task(
                    "12345678902",
                    "Task 1",
                    "Gather requirements");

        });
    }

    //Task Name Character TOO LONG length test
    @Test

    void testTaskNameLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Task(
                    "1234567890",
                    "module 4 assignment Task object",
                    "Gather requirements");

        });
    }

    //Task Description Character TOO LONG length test
    @Test

    void testTaskDescriptionLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Task(
                    "1234567890",
                    "Task 1",
                    "Rubrics says Gather requirements but over fifty characters is way too long");
        });
    }
}
