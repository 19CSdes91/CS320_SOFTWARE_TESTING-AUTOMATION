/*
Task Requirements
The task object shall have a required unique task ID String that cannot be longer than 10 characters. The task ID shall not be null and shall not be updatable.
 The task object shall have a required name String field that cannot be longer than 20 characters. The name field shall not be null.
The task object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.
*/
public class Task {
    //Cannot be null
    private final String taskId;//1-10char, cannot update
    private String taskName;//1-20char
    private String taskDescription;//1-50

    //Constructor
    public Task(String taskId, String taskName, String taskDescription) {

        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid ID");
        }

        if (taskName == null || taskName.length() > 20) {
            throw new IllegalArgumentException("Invalid Task name");
        }

        if (taskDescription == null || taskDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }

        this.taskId = taskId;
        this.taskName = taskName;
        this.taskDescription = taskDescription;
    }

    //getters
    public String getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    //Setters
    public void setTaskName(String taskName) {
        if (taskName == null || taskName.length() > 20) {
            throw new IllegalArgumentException("Invalid Task Name ");
        }
        this.taskName = taskName;
    }

    public void setTaskDescription(String taskDescription) {
        if (taskDescription == null || taskDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }
        this.taskDescription = taskDescription;
    }


}
