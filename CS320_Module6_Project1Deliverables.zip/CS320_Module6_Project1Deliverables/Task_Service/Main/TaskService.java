import java.util.ArrayList;
import java.util.List;

/*Task Service Requirements
*The task service shall be able to add tasks with a unique ID.
*The task service shall be able to delete tasks per taskId.
*The task service shall be able to update task fields per taskId.

The following fields are updatable:
**name
**description
 */

public class TaskService {

    //Store all tasks in memory.
    private final List<Task> tasks = new ArrayList<>();

    //add task
    public boolean addTask(Task task) {

        //Task cannot be null/empty
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be empty!");
        }

        //ID must be unique-No duplicates
        for (Task existingTask : tasks) {
            if (existingTask.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("ID is already in use!");
            }
        }
        //Add task to tasks, if duplicate was not found
        tasks.add(task);
        return true;
    }

    //Delete task
    public boolean deleteTask(String taskId) {

        for (Task existingTask : tasks) {

            if (existingTask.getTaskId().equals(taskId)) {

                tasks.remove(existingTask);
                return true;
            }
        }

        // If ID  is not found
        throw new IllegalArgumentException("Task cannot be found");
    }

    //update Task name
    public boolean updateTaskName(String taskId, String taskName) {

        for (Task existingTask : tasks) {

            if (existingTask.getTaskId().equals(taskId)) {
                existingTask.setTaskName(taskName);
                return true;
            }
        }

        throw new IllegalArgumentException("Task not found");
    }

    //update Task Description
    public boolean updateTaskDescription(String taskId, String taskDescription) {

        for (Task existingTask : tasks) {

            if (existingTask.getTaskId().equals(taskId)) {
                existingTask.setTaskDescription(taskDescription);
                return true;
            }
        }

        throw new IllegalArgumentException("Task Not found");
    }
}
