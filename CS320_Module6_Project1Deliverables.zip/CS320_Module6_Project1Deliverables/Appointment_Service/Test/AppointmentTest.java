import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/*Test cases for Appointment include:
 * Happy path, testing valid Appointment creation
 * Null test, is it empty
 * Length test, is it too long
 *   -ID>10
 *   -Desc>50
 * Invalid date test **Cannot be in the past**
 * */


    class AppointmentTest {

        //set local date to current day
        private final LocalDate today = LocalDate.now();

        //"Happy path" Test
        @Test

        void testAppointmentCreation() {

            Appointment appointment = new Appointment(
                    "1234567890",
                    today,
                    "Client appointment 1");

            assertEquals("1234567890", appointment.getAppointmentId());
            assertEquals(today, appointment.getAppointmentDate());
            assertEquals("Client appointment 1", appointment.getAppointmentDescription());
        }

        //Appointment ID NULL test
        @Test

        void testAppointmentIdNull() {

            assertThrows(IllegalArgumentException.class,() ->{
                new Appointment(
                        null,
                        today,
                        "Client appointment 1");
            });
        }

        //Appointment date NULL test
        @Test

        void testAppointmentDateNull() {
            assertThrows(IllegalArgumentException.class,() ->{
                new Appointment(
                        "1234567890",
                        null,
                        "Client appointment 1");
            });
        }

        //Appointment Description NULL test
        @Test

        void testAppointmentDescriptionNull() {
            assertThrows(IllegalArgumentException.class, () -> {
                new Appointment(
                        "1234567890",
                        today,
                        null);
            });
        }

        //Appointment ID Character TOO LONG length test
        @Test

        void testAppointmentIdLong() {
            assertThrows(IllegalArgumentException.class,() ->{
                new Appointment(
                        "12345678902",
                        today,
                        "Client appointment 1");

            });
        }

        //Appointment Description Character TOO LONG length test
        @Test

        void testAppointmentDescriptionLong() {
            assertThrows(IllegalArgumentException.class,() ->{
                new Appointment(
                        "1234567890",
                        today,
                        "Rubrics says Gather requirements but over fifty characters is way too long");
            });
        }


    //Appointment date in past
        @Test

        void testAppointmentDatePast() {

            LocalDate yesterday = today.minusDays(1);
            assertThrows(IllegalArgumentException.class,() ->{
                new Appointment(
                        "1234567890",
                        yesterday,
                        "Client appointment1");
            });
        }

        //Test setting future appointment
        @Test

        void testFutureAppointment () {
            Appointment appointment = new Appointment(
                    "1234567890",
                    today,
                    "Client appointment1");

            //Create new appointment date
            LocalDate tomorrow = today.plusDays(1);

            appointment.setAppointmentDate(tomorrow);

            assertEquals(tomorrow, appointment.getAppointmentDate());
        }

            //Test setting description with update
            @Test

            void testUpdatedDescription() {
                Appointment appointment = new Appointment(
                        "1234567890",
                        today,
                        "Client appointment1");

                //update
                appointment.setAppointmentDescription("Client appointment2");

                assertEquals("Client appointment2", appointment.getAppointmentDescription());
        }
}