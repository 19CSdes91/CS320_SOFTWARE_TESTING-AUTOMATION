import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
/*Appointment Service test cases include:
 *Add appointment
 * Delete Appointment test
 * Unique appointment ID, no duplicates
 * Appointment not found test
 * */


class AppointmentServiceTest {

    //set local date to current day
    private final LocalDate today = LocalDate.now();

    //Add Appointment test
    @Test

    void addAppointmentTest(){
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment(
                "1234567890",
                today,
                "Client appointment 1");


        assertTrue(service.addAppointment(appointment));
    }

    //Delete Appointment test
    @Test

    void deleteAppointmentTest(){
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment(
                "1234567890",
                today,
                "Client appointment 1");
        service.addAppointment(appointment);

        assertTrue(service.deleteAppointment("1234567890"));
    }

    //Duplicate Appointment test
    @Test

    void duplicateAppointmentTest(){
        AppointmentService service = new AppointmentService();

        //Appointment 1
        Appointment appointment1 = new Appointment(
                "1234567890",
                today,
                "Client appointment 1");

        //The Duplicate^^^
        Appointment appointment2 = new Appointment(
                "1234567890",
               today,
                "Client appointment 2");

        service.addAppointment(appointment1);
        assertThrows (IllegalArgumentException.class,() -> {
            service.addAppointment(appointment2);
        });
    }

    //Appointment not found
    @Test

    void AppointmentNotFoundTest() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("1234567890");
        });
    }

    // Test add a NULL test
    @Test

    void addNulltest(){
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }


}
