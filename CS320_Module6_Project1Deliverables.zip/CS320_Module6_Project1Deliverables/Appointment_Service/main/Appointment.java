import  java.time.LocalDate;



public class Appointment {

    //Cannot be null
    private final String appointmentId;//1-10char, cannot update
    private LocalDate appointmentDate;//Cannot be before present day(past)
    private String appointmentDescription;//1-50


    //Constructor
    public Appointment(String appointmentId, LocalDate appointmentDate, String appointmentDescription) {

        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid ID");
        }

        if (appointmentDate == null || appointmentDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Invalid Date");
        }

        if (appointmentDescription == null || appointmentDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.appointmentDescription = appointmentDescription;
    }
    //getters
    public String getAppointmentId() {
        return appointmentId;
    }

    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    //Setters
    public void setAppointmentDate(LocalDate appointmentDate) {
        if (appointmentDate == null || appointmentDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Invalid Appointment Date! ");
        }
        this.appointmentDate = appointmentDate;
    }

    public void setAppointmentDescription(String appointmentDescription) {
        if (appointmentDescription == null || appointmentDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }
        this.appointmentDescription = appointmentDescription;
    }

}




