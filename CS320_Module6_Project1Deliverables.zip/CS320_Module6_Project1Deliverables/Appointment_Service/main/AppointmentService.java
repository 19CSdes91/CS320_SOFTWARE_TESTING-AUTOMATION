import java.util.ArrayList;
import java.util.List;

/*Appointment Service Requirements
*appointment service shall be able to add appointments with a unique appointmentId.
*appointment service shall be able to delete appointments per appointmentId
*/

public class AppointmentService {

    //Store all appointments in memory.
    private final List <Appointment> appointments = new ArrayList<>();

    //add appointment
    public boolean addAppointment(Appointment appointment) {

        //Appointment cannot be null/empty
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be empty!");
        }

        //ID must be unique-No duplicates
        for (Appointment existingAppointment : appointments) {
            if (existingAppointment.getAppointmentId().equals(appointment.getAppointmentId())) {
                throw new IllegalArgumentException("ID is already in use!");
            }
        }
        //Add appointment to appointments, if duplicate was not found
        appointments.add(appointment);
        return true;
    }

    //Delete appointment
    public boolean deleteAppointment(String appointmentId) {

        for (Appointment existingAppointment : appointments) {

            if (existingAppointment.getAppointmentId().equals(appointmentId)) {

                appointments.remove(existingAppointment);
                return true;
            }
        }

        // If ID  is not found
        throw new IllegalArgumentException("Appointment cannot be found");
    }
    }