import java.util.ArrayList;
import java.util.List;

/*Contact Service Requirements
*Illegal argument exception null and duplicate
*The contact service shall be able to add contacts with unique ID.
*The contact service shall be able to delete contacts per contactId.
*The contact service shall be able to update contact fields per contactId. The following fields are updatable:
firstName
lastName
PhoneNumber
Address*/


//Store all contacts in memory.
public class ContactService {

    private List<Contact> contacts = new ArrayList<>();


    public boolean addContact(Contact contact) {

        for (Contact existingContact : contacts) {

            if (existingContact.getContactId().equals(contact.getContactId())) {

                throw new IllegalArgumentException("Duplicate ID");
            }
        }


        contacts.add(contact);
        return true;
    }

    //Delete Contact
    public boolean deleteContact (String contactId){

        for (Contact existingContact : contacts) {

            if (existingContact.getContactId().equals(contactId)) {
                contacts.remove(existingContact);
                return true;
            }
        }
        throw new IllegalArgumentException("ContactID not found");
    }

    //Update first name
    public boolean updateFirstName (String contactId,String newFirstName){

        for (Contact existingContact : contacts) {

            if (existingContact.getContactId().equals(contactId)) {
                existingContact.setFirstName(newFirstName);
                return true;
            }
        }
        throw new IllegalArgumentException("ContactID not found");
    }

    //Update last name
    public boolean updateLastName (String contactId,String newLastName){

        for (Contact existingContact : contacts) {

            if (existingContact.getContactId().equals(contactId)) {
                existingContact.setLastName(newLastName);
                return true;
            }
        }
        throw new IllegalArgumentException("ContactID not found");
    }

    //Update Phone
    public boolean updatePhone (String contactId,String newPhone){

        for (Contact existingContact : contacts) {

            if (existingContact.getContactId().equals(contactId)) {
                existingContact.setPhone(newPhone);
                return true;
            }
        }
        throw new IllegalArgumentException("ContactID not found");
    }

    //Update address
    public boolean updateAddress (String contactId,String newAddress){

        for (Contact existingContact : contacts) {

            if (existingContact.getContactId().equals(contactId)) {
                existingContact.setAddress(newAddress);
                return true;
            }
        }
        throw new IllegalArgumentException("ContactID not found");
    }
}
