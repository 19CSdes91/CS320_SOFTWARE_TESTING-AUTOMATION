/*Textbook pg  97 basic assertions
import static org.juint.jupiter.api.Assertions.assertEquals;
import static org.juint.jupiter.api.Assertions.assertFalse;
import static org.juint.jupiter.api.Assertions.assertTrue;
import static org.juint.jupiter.api.Test;*/

/*Contact Class Requirements
*The contact object shall have a required unique contact ID String that cannot be longer than 10 characters. The contact ID shall not be null and shall not be updatable.
*The contact object shall have a required firstName String field that cannot be longer than 10 characters. The firstName field shall not be null.
*The contact object shall have a required lastName String field that cannot be longer than 10 characters. The lastName field shall not be null.
*The contact object shall have a required phone String field that must be exactly 10 digits. The phone field shall not be null.
*The contact object shall have a required address field that must be no longer than 30 characters. The address field shall not be null.
*/

public class Contact {
    //Use alt + ENTER, then select CREATE TEST to create JUNIT test.
    //Fields
    private String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;


    //Constructor
    public Contact(String contactId, String firstName, String lastName, String
            phone, String address) {

        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid ID");
        }

        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }

        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid phone");
        }

        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    //getters
    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    //Setters
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }

    //update phone
    public void setPhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid phone number ");
        }
        this.phone = phone;
    }

    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
        this.address = address;
    }
}
