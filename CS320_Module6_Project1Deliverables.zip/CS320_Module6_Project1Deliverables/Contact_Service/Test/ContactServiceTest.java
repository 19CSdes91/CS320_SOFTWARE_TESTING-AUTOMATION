import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/*
Test cases include:
*Add task
*update test
* Duplicate test, check for doubles
* Delete Task test*/

class ContactServiceTest {
    //Add contact test
    @Test

    void contactAddTest(){
        ContactService service = new ContactService();
        Contact contact = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");

        assertTrue(service.addContact(contact));
    }

    //Duplicate contact test
    @Test

    void contactDuplicateTest(){
        ContactService service = new ContactService();

        //Contact 1
        Contact contact1 = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");

        //Duplicate
        Contact contact2 = new Contact(
                "001",
                "Salvador",
                "Dali",
                "0987654321",
                "Portlligat, Spain");

        service.addContact(contact1);
       assertThrows (IllegalArgumentException.class,() -> {
           service.addContact(contact2);
        });
    }

    //Update first name test
    @Test

    void firstNameUpdateTest(){
        ContactService service = new ContactService();
        Contact contact = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");
        service.addContact(contact);

        assertTrue(service.updateFirstName(
                "001",
                "Leo"

        ));
        assertEquals("Leo", contact.getFirstName());
    }

    //Update Last name test
    @Test

    void lastNameUpdateTest(){
        ContactService service = new ContactService();
        Contact contact = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");
        service.addContact(contact);

        assertTrue(service.updateLastName(
                "001",
                "Vinci"

        ));
        assertEquals("Vinci", contact.getLastName());
    }

    //update phone
    @Test

    void phoneUpdateTest(){
        ContactService service = new ContactService();
        Contact contact = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");
        service.addContact(contact);

        assertTrue(service.updatePhone(
                "001",
                "8888888888"

        ));
        assertEquals("8888888888", contact.getPhone());
    }

    //update address
    @Test

    void addressUpdateTest(){
        ContactService service = new ContactService();
        Contact contact = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");
        service.addContact(contact);

        assertTrue(service.updateAddress(
                "001",
                "Florence, Italy"

        ));
        assertEquals("Florence, Italy", contact.getAddress());
    }

    //Delete contact test
    @Test

    void contactDeleteTest(){
        ContactService service = new ContactService();
        Contact contact = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");
        service.addContact(contact);

        assertTrue(service.deleteContact("001"));
    }

}