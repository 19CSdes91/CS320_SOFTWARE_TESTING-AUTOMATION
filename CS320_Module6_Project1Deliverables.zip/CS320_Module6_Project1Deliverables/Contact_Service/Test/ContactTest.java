
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/*Test cases for Task include:
 * Happy path, testing valid task creation
 * Length test, is it too long
 * Phone lengeth, is it too short
 * Null test, is it empty
 **Test Getters
 *A*Test Setters w/ contact update
 *
 * */

class ContactTest {
    //"Happy Path" Test
    @Test
    void testContactIdValidity() {
        Contact contact = new Contact(
                "001",
                "Leonardo",
                "Da Vinci",
                "1234567890",
                "Chateau Du Clos Luche");

        assertEquals("001", contact.getContactId());
    }

    //Contact ID length TOO LONG test
    @Test
    void testContactIdLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "12345678910",
                    "Leonardo",
                    "Da Vinci",
                    "1234567890",
                    "Chateau Du Clos Luche");
        });
    }
    //First Name Character TOO LONG length test
    @Test
    void testFirstNameLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo0000",
                    "Da Vinci",
                    "1234567890",
                    "Chateau Du Clos Luche");
        });
    }

    //Last Name Character TOO LONG length test
    @Test
    void testLastNameLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    "Da Vinci111",
                    "1234567890",
                    "Chateau Du Clos Luche");
        });
    }

    //Phone Character TOO LONG length test
    @Test
    void testPhoneLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    "Da Vinci",
                    "123456789012",
                    "Chateau Du Clos Luche");
        });
    }
    //Address Character TOO LONG length test
    @Test
    void testAddressLong() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    "Da Vinci",
                    "1234567890",
                    "Château du Clos Lucé, 2 Rue du Clos Lucé, 37400 Amboise, France");
        });
    }

    //Contact ID NULL test
    @Test
    void testContactIdNull() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    null,
                    "Leonardo",
                    "Da Vinci",
                    "1234567890",
                    "Château du Clos Lucé");
        });
    }
    //first name NULL test
    @Test
    void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    null,
                    "Da Vinci",
                    "1234567890",
                    "Château du Clos Lucé");
        });
    }

    //Last Name NULL test
    @Test
    void testLastNameNull() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    null,
                    "1234567890",
                    "Château du Clos Lucé");
        });
    }

    //Phone NULL test
    @Test
    void testPhoneNull() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    "Da Vinci",
                    null,
                    "Château du Clos Lucé");
        });
    }
    //Address NULL test
    @Test
    void testAddressNull() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    "Da Vinci",
                    "1234567890",
                    null);
        });
    }
    //Phone TOO SHORT test
    @Test
    void testPhoneShort() {
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    " Da Vinci",
                    "1234",
                    "Château du Clos Lucé");
        });
    }

    //Test Phone with invalid number input using other characters
    @Test
    void testPhoneNonNumber(){
        assertThrows(IllegalArgumentException.class,() ->{
            new Contact(
                    "001",
                    "Leonardo",
                    " Da Vinci",
                    "12345aBcd?",
                    "Château du Clos Lucé");
        });
    }

    //Test getters
    @Test

    void testContactGetters () {
        Contact contact = new Contact("001","Leonardo", "Da Vinci", "1234567890", "Chateau Du Clos Luche");

        assertEquals ("001", contact.getContactId());
        assertEquals ("Leonardo", contact.getFirstName());
        assertEquals ("Da Vinci", contact.getLastName());
        assertEquals ("1234567890", contact.getPhone());
        assertEquals ("Chateau Du Clos Luche", contact.getAddress());

    }

    //Test Setter with contact update
    @Test

    void testContactSetters() {
        Contact contact = new Contact("001","Leonardo", "Da Vinci", "1234567890", "Chateau Du Clos Luche");

        //update First namee
        contact.setFirstName("Leo");
        assertEquals("Leo",contact.getFirstName());

        //update last Name
        contact.setLastName("Vinci");
        assertEquals("Vinci",contact.getLastName());

        //Update phone Number
        contact.setPhone("0987654321");
        assertEquals("0987654321",contact.getPhone());

        //Update address
        contact.setAddress("Florence");
        assertEquals("Florence",contact.getAddress());


    }


}
